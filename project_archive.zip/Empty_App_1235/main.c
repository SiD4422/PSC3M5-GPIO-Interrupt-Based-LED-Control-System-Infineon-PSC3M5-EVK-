#include "cybsp.h"
#include "cy_device_headers.h"
#include "cy_pdl.h"
#include <stdbool.h>

/* LED Pins  */
#define LED_YELLOW_PORT     GPIO_PRT8
#define LED_YELLOW_PIN      4
#define LED_BLUE_PORT       GPIO_PRT8
#define LED_BLUE_PIN        5

/* BTN1 → P5_0 (ACTIVE HIGH) */
/* BTN2 → P0_4 (ACTIVE LOW) */
#define BTN1_PORT           GPIO_PRT5
#define BTN1_PIN            0
#define BTN2_PORT           GPIO_PRT0
#define BTN2_PIN            4

volatile bool btn1_flag = false;
volatile bool btn2_flag = false;

/* BTN1 ISR – Rising edge */
void btn1_isr(void)
{
    Cy_GPIO_ClearInterrupt(BTN1_PORT, BTN1_PIN);
    btn1_flag = true;
}

/* BTN2 ISR – Falling edge */
void btn2_isr(void)
{
    Cy_GPIO_ClearInterrupt(BTN2_PORT, BTN2_PIN);
    btn2_flag = true;
}

int main(void)
{
    cy_rslt_t result = cybsp_init();
    if (result != CY_RSLT_SUCCESS) { CY_ASSERT(0); }

    __enable_irq();

    /* Configure LEDs */
    Cy_GPIO_Pin_FastInit(LED_YELLOW_PORT, LED_YELLOW_PIN,
                         CY_GPIO_DM_STRONG, 0, HSIOM_SEL_GPIO);

    Cy_GPIO_Pin_FastInit(LED_BLUE_PORT, LED_BLUE_PIN,
                         CY_GPIO_DM_STRONG, 0, HSIOM_SEL_GPIO);

    /* Configure BTN1 interrupt  */
    Cy_GPIO_Pin_FastInit(BTN1_PORT, BTN1_PIN,
                         CY_GPIO_DM_PULLDOWN, 0, HSIOM_SEL_GPIO);
    Cy_GPIO_SetInterruptEdge(BTN1_PORT, BTN1_PIN, CY_GPIO_INTR_RISING);
    Cy_GPIO_ClearInterrupt(BTN1_PORT, BTN1_PIN);
    Cy_SysInt_Init(&((cy_stc_sysint_t){.intrSrc = ioss_interrupts_gpio_5_IRQn,
                                       .intrPriority = 3}),
                   btn1_isr);
    NVIC_EnableIRQ(ioss_interrupts_gpio_5_IRQn);

    /* Configure BTN2 interrupt  */
    Cy_GPIO_Pin_FastInit(BTN2_PORT, BTN2_PIN,
                         CY_GPIO_DM_PULLUP, 1, HSIOM_SEL_GPIO);
    Cy_GPIO_SetInterruptEdge(BTN2_PORT, BTN2_PIN, CY_GPIO_INTR_FALLING);
    Cy_GPIO_ClearInterrupt(BTN2_PORT, BTN2_PIN);
    Cy_SysInt_Init(&((cy_stc_sysint_t){.intrSrc = ioss_interrupts_gpio_0_IRQn,
                                       .intrPriority = 3}),
                   btn2_isr);
    NVIC_EnableIRQ(ioss_interrupts_gpio_0_IRQn);

    for (;;)
    {
        if (btn1_flag)
        {
            btn1_flag = false;
            Cy_GPIO_Inv(LED_YELLOW_PORT, LED_YELLOW_PIN);
        }

        if (btn2_flag)
        {
            btn2_flag = false;
            Cy_GPIO_Inv(LED_BLUE_PORT, LED_BLUE_PIN);
        }
    }
}
