var searchData=
[
  ['peripheral_20default_20bsp_20settings_0',['Peripheral Default BSP Settings',['../md_source_bsps_cat1b_KIT_PSC3M5_EVK_bsp_settings.html',1,'']]]
];
