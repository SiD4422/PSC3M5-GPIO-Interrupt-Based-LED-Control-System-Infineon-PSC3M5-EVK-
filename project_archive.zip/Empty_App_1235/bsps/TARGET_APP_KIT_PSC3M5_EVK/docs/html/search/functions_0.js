var searchData=
[
  ['cybsp_5finit_0',['cybsp_init',['../group__group__bsp__functions.html#gab989986b285e127f78f61c29f6ccbbfa',1,'cybsp_init(void):&#160;cybsp.c'],['../group__group__bsp__functions.html#gab989986b285e127f78f61c29f6ccbbfa',1,'cybsp_init(void):&#160;cybsp.c']]],
  ['cybsp_5fsyspm_5fdo_5fwarmboot_1',['cybsp_syspm_do_warmboot',['../group__group__bsp__dsram__functions.html#gaeaa97ebf2a7a769589bf24bb2d306fb4',1,'cybsp_syspm_do_warmboot(void):&#160;cybsp_dsram.c'],['../group__group__bsp__dsram__functions.html#gaeaa97ebf2a7a769589bf24bb2d306fb4',1,'cybsp_syspm_do_warmboot(void):&#160;cybsp_dsram.c']]],
  ['cybsp_5fsyspm_5fdsram_5finit_2',['cybsp_syspm_dsram_init',['../group__group__bsp__dsram__functions.html#gae9217e4b92ef5f9cda69a3bc26b9a5a8',1,'cybsp_syspm_dsram_init(void):&#160;cybsp_dsram.c'],['../group__group__bsp__dsram__functions.html#gae9217e4b92ef5f9cda69a3bc26b9a5a8',1,'cybsp_syspm_dsram_init(void):&#160;cybsp_dsram.c']]]
];
