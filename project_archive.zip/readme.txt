ModusToolbox™ archive file
==========================
This file was created by the ModusToolbox™ archive (mtbarchive) program to assist with sharing applications between colleagues without using a version control system, such as Git.
This archive file contains the following ModusToolbox™ applications/projects:
- Empty_App_1235

Using the archive file
----------------------
Do the following to use this archive file in your preferred flow:
1. Create a folder and extract the archive file into it.
2. Open the application/project folder that includes the Makefile in a terminal (modus-shell on Windows).
3. Run the command: make getlibs. This creates the mtb_shared folder.
4. Run the command: make [ide], where [ide] is: eclipse, vscode, iar, or uvision. This generates needed IDE files.
Refer to the applicable user guide for details for your preference (located in
[install-path]/ModusToolbox/docs_[version]):
 * command line: ModusToolbox™ tools package user guide (mtb_user_guide.pdf)
 * VS Code for ModusToolbox™ user guide (mt_vscode_user_guide.pdf)
 * Eclipse for ModusToolbox™ user guide (mt_ide_user_guide.pdf)
 * IAR Embedded Workbench for ModusToolbox™ user guide (mt_iar_user_guide.pdf)
 * Keil μVision for ModusToolbox™ user guide (mt_uvision_user_guide.pdf)
